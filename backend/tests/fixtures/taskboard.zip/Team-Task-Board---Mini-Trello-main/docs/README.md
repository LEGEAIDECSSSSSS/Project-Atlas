Legacy diagrams from the first version of the project live in `diagrams-legacy/`. They describe the old
single-organisation design (global user roles, JSON member lists) and are kept for reference only.
