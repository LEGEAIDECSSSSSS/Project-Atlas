import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useAuth } from './auth'
import { Loading } from './ui/bits'
import AppShell from './components/AppShell'
import OrgLayout from './components/OrgLayout'
import HomeRedirect from './pages/HomeRedirect'
import Login from './pages/Login'
import Register from './pages/Register'
import VerifyEmail from './pages/VerifyEmail'
import { ForgotPassword, ResetPassword } from './pages/PasswordPages'
import Welcome from './pages/Welcome'
import NewOrg from './pages/NewOrg'
import Overview from './pages/Overview'
import Teams from './pages/Teams'
import TeamPage from './pages/TeamPage'
import Members from './pages/Members'
import Activity from './pages/Activity'
import OrgSettings from './pages/OrgSettings'
import MyWork from './pages/MyWork'
import Invitations from './pages/Invitations'
import Profile from './pages/Profile'

function RequireAuth({ children }) {
  const { user, isLoading } = useAuth()
  const location = useLocation()
  if (isLoading) return <Loading />
  if (!user) {
    const next = encodeURIComponent(location.pathname + location.search)
    return <Navigate to={`/login?next=${next}`} replace />
  }
  return children
}

function PublicOnly({ children }) {
  const { user, isLoading } = useAuth()
  if (isLoading) return <Loading />
  return user ? <Navigate to="/" replace /> : children
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
      <Route path="/register" element={<PublicOnly><Register /></PublicOnly>} />
      <Route path="/forgot-password" element={<PublicOnly><ForgotPassword /></PublicOnly>} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/verify-email" element={<VerifyEmail />} />

      <Route element={<RequireAuth><AppShell /></RequireAuth>}>
        <Route index element={<HomeRedirect />} />
        <Route path="welcome" element={<Welcome />} />
        <Route path="orgs/new" element={<NewOrg />} />
        <Route path="my-work" element={<MyWork />} />
        <Route path="invitations" element={<Invitations />} />
        <Route path="profile" element={<Profile />} />
        <Route path="o/:orgId" element={<OrgLayout />}>
          <Route index element={<Overview />} />
          <Route path="teams" element={<Teams />} />
          <Route path="teams/:teamId" element={<TeamPage />} />
          <Route path="members" element={<Members />} />
          <Route path="activity" element={<Activity />} />
          <Route path="settings" element={<OrgSettings />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
