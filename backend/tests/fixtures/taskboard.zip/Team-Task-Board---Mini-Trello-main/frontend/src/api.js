// Thin fetch wrapper around the FastAPI backend.
//  - cookies carry the session (httpOnly, so no token ever touches JavaScript)
//  - a 401 triggers exactly one silent refresh, then the original request is retried
//  - errors become ApiError with the server's message, code, and per-field messages

const BASE = (import.meta.env.VITE_API_URL ?? '') + '/api'

export class ApiError extends Error {
  constructor(message, { status, code, fields } = {}) {
    super(message)
    this.status = status
    this.code = code
    this.fields = fields || {}
  }
}

let refreshing = null
const listeners = new Set()
export const onSessionExpired = (fn) => {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

async function refreshSession() {
  // Refresh tokens rotate, so concurrent refreshes would invalidate each other. Share one.
  refreshing ??= fetch(`${BASE}/auth/refresh`, { method: 'POST', credentials: 'include' })
    .then((r) => r.ok)
    .catch(() => false)
    .finally(() => {
      refreshing = null
    })
  return refreshing
}

async function request(method, path, body, retry = true) {
  let response
  try {
    response = await fetch(BASE + path, {
      method,
      credentials: 'include',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new ApiError("Can't reach the server. Check your connection and try again.", { status: 0, code: 'network' })
  }

  if (response.status === 401 && retry && !path.startsWith('/auth/')) {
    if (await refreshSession()) return request(method, path, body, false)
    listeners.forEach((fn) => fn())
  }

  if (response.status === 204) return null
  let data = null
  try {
    data = await response.json()
  } catch {
    /* empty body */
  }
  if (!response.ok) {
    throw new ApiError(data?.detail || 'Something went wrong. Try again.', {
      status: response.status,
      code: data?.code,
      fields: data?.fields,
    })
  }
  return data
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body ?? {}),
  patch: (path, body) => request('PATCH', path, body ?? {}),
  del: (path) => request('DELETE', path),
}
