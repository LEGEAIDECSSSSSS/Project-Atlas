import { createContext, useCallback, useContext, useEffect, useMemo } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { api, ApiError, onSessionExpired } from './api'

const AuthContext = createContext(null)

// Never clear the whole cache: that would also destroy the in-flight ['me'] query and loop forever.
const forgetEverythingElse = (queryClient) =>
  queryClient.removeQueries({ predicate: (query) => query.queryKey[0] !== 'me' })

export function AuthProvider({ children }) {
  const queryClient = useQueryClient()

  const { data: user, isLoading } = useQuery({
    queryKey: ['me'],
    queryFn: async () => {
      try {
        return await api.get('/me')
      } catch (error) {
        if (error instanceof ApiError && error.status === 401) return null
        throw error
      }
    },
    staleTime: Infinity,
    retry: false,
  })

  // If a refresh fails mid-session, drop everything and send the person to the login screen.
  useEffect(
    () =>
      onSessionExpired(() => {
        forgetEverythingElse(queryClient)
        queryClient.setQueryData(['me'], null)
      }),
    [queryClient],
  )

  const login = useCallback(
    async (email, password) => {
      const me = await api.post('/auth/login', { email, password })
      forgetEverythingElse(queryClient)
      queryClient.setQueryData(['me'], me)
      return me
    },
    [queryClient],
  )

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout')
    } finally {
      forgetEverythingElse(queryClient)
      queryClient.setQueryData(['me'], null)
    }
  }, [queryClient])

  const value = useMemo(() => ({ user: user ?? null, isLoading, login, logout }), [user, isLoading, login, logout])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
