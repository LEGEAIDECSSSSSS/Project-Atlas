import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useMatch, useNavigate } from 'react-router-dom'
import {
  Activity as ActivityIcon,
  ClipboardList,
  Inbox,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  Plus,
  Settings,
  Sun,
  UserRound,
  Users,
  UsersRound,
} from 'lucide-react'
import { useAuth } from '../auth'
import { useMyInvitations, useMyOrgs, useOrg } from '../queries'
import { useTheme } from '../theme'
import { isOrgAdmin } from '../lib/rules'
import { monogram, orgTileStyle, ROLE_LABEL } from '../lib/format'
import { Avatar, BrandMark } from '../ui/bits'

export default function AppShell() {
  const { user, logout } = useAuth()
  const { theme, toggle } = useTheme()
  const navigate = useNavigate()
  const location = useLocation()
  const [open, setOpen] = useState(false)
  const match = useMatch('/o/:orgId/*')
  const orgId = match?.params.orgId

  const { data: orgs = [] } = useMyOrgs()
  const { data: invitations = [] } = useMyInvitations()
  const { data: current } = useOrg(orgId)

  useEffect(() => setOpen(false), [location.pathname])

  const role = current?.role
  const orgName = current?.organisation.name
  const base = `/o/${orgId}`
  const link = ({ isActive }) => `nav-link ${isActive ? 'active' : ''}`

  return (
    <div className="shell">
      <header className="topbar">
        <button className="icon-btn" onClick={() => setOpen(true)} aria-label="Open navigation">
          <Menu size={20} />
        </button>
        <strong>{orgName || 'TaskBoard'}</strong>
      </header>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}

      <div className="nav-drawer" data-open={open}>
        <nav className="rail" aria-label="Organisations">
          <Link to="/" className="rail-brand" aria-label="TaskBoard home">
            <BrandMark size={34} />
          </Link>
          <div className="rail-sep" />
          {orgs.map(({ organisation }) => (
            <Link
              key={organisation.id}
              to={`/o/${organisation.id}`}
              className="org-tile"
              style={orgTileStyle(organisation.name)}
              aria-current={String(organisation.id) === orgId}
              aria-label={organisation.name}
              title={organisation.name}
            >
              {monogram(organisation.name)}
            </Link>
          ))}
          <Link to="/orgs/new" className="rail-btn" aria-label="Create or join an organisation" title="New organisation">
            <Plus size={18} />
          </Link>
          <div className="rail-spacer" />
          <button className="rail-btn solid" onClick={toggle} aria-label="Toggle dark mode" title="Toggle theme">
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </nav>

        <aside className="side">
          {orgId && current ? (
            <>
              <div className="side-org">
                <h2>{orgName}</h2>
                <span className="role">Your role here: {ROLE_LABEL[role]?.toLowerCase()}</span>
              </div>
              <NavLink to={base} end className={link}>
                <LayoutDashboard size={18} /> Overview
              </NavLink>
              <NavLink to={`${base}/teams`} className={link}>
                <UsersRound size={18} /> Teams
              </NavLink>
              <NavLink to={`${base}/members`} className={link}>
                <Users size={18} /> Members
              </NavLink>
              {isOrgAdmin(role) && (
                <NavLink to={`${base}/activity`} className={link}>
                  <ActivityIcon size={18} /> Activity
                </NavLink>
              )}
              <NavLink to={`${base}/settings`} className={link}>
                <Settings size={18} /> Settings
              </NavLink>
            </>
          ) : (
            <div className="side-org">
              <h2>TaskBoard</h2>
              <span className="role">{orgs.length ? `${orgs.length} organisation${orgs.length > 1 ? 's' : ''}` : 'No organisation yet'}</span>
            </div>
          )}

          <div className="side-group">Across all organisations</div>
          <NavLink to="/my-work" className={link}>
            <ClipboardList size={18} /> My work
          </NavLink>
          <NavLink to="/invitations" className={link}>
            <Inbox size={18} /> Invitations
            {invitations.length > 0 && <span className="count">{invitations.length}</span>}
          </NavLink>
          <NavLink to="/profile" className={link}>
            <UserRound size={18} /> Profile
          </NavLink>

          <div className="side-foot">
            <Avatar name={user.name} size={34} />
            <div className="who">
              <strong>{user.name}</strong>
              <span>{user.email}</span>
            </div>
            <button
              className="icon-btn"
              aria-label="Log out"
              title="Log out"
              onClick={async () => {
                await logout()
                navigate('/login')
              }}
            >
              <LogOut size={18} />
            </button>
          </div>
        </aside>
      </div>

      <main className="main">
        <div className="content">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
