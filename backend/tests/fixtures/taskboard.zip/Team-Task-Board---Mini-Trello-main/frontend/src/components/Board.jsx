import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Clock } from 'lucide-react'
import { api } from '../api'
import { keys } from '../queries'
import { moveBlockedReason } from '../lib/rules'
import { formatDue, STATUSES } from '../lib/format'
import { Avatar } from '../ui/bits'
import { useToast } from '../ui/Toast'

/** Moves a todo between lanes with an optimistic update, rolling back if the server says no. */
export function useMoveTodo(orgId, teamId) {
  const queryClient = useQueryClient()
  const toast = useToast()
  const key = keys.todos(orgId, teamId)
  return useMutation({
    mutationFn: ({ id, status }) => api.post(`/orgs/${orgId}/todos/${id}/status`, { status }),
    onMutate: async ({ id, status }) => {
      await queryClient.cancelQueries({ queryKey: key })
      const previous = queryClient.getQueryData(key)
      queryClient.setQueryData(key, (old = []) => old.map((t) => (t.id === id ? { ...t, progress: status } : t)))
      return { previous }
    },
    onError: (error, _vars, context) => {
      queryClient.setQueryData(key, context?.previous)
      toast.error(error.message)
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: key })
      queryClient.invalidateQueries({ queryKey: keys.tasks(orgId, teamId) })
      queryClient.invalidateQueries({ queryKey: keys.teams(orgId) })
      queryClient.invalidateQueries({ queryKey: keys.myTodos })
    },
  })
}

function TodoCard({ todo, draggable, onOpen, onDragStart, onDragEnd, dragging }) {
  return (
    <div
      className="todo-card"
      role="button"
      tabIndex={0}
      draggable={draggable}
      data-priority={todo.priority}
      data-dragging={dragging}
      onClick={() => onOpen(todo)}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onOpen(todo))}
      onDragStart={(e) => {
        e.dataTransfer.setData('text/plain', String(todo.id))
        e.dataTransfer.effectAllowed = 'move'
        onDragStart(todo)
      }}
      onDragEnd={onDragEnd}
      aria-label={`${todo.title}. ${todo.assigned_to_name ? `Assigned to ${todo.assigned_to_name}.` : 'Unassigned.'}`}
    >
      <div className="t">{todo.title}</div>
      <div className="from">{todo.task_title}</div>
      <div className="foot">
        {todo.due && (
          <span className={`due ${todo.is_late ? 'late' : ''}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Clock size={12} /> {formatDue(todo.due)}
          </span>
        )}
        <span className="grow" />
        {todo.assigned_to_name ? <Avatar name={todo.assigned_to_name} size={24} /> : <span>Unassigned</span>}
      </div>
    </div>
  )
}

export default function Board({ orgId, teamId, todos, tasks, canManage, userId, onOpen, onCreate }) {
  const move = useMoveTodo(orgId, teamId)
  const toast = useToast()
  const [taskFilter, setTaskFilter] = useState('')
  const [mineOnly, setMineOnly] = useState(false)
  const [dragging, setDragging] = useState(null)
  const [hover, setHover] = useState('')

  const visible = todos.filter((t) => (!taskFilter || String(t.task_id) === taskFilter) && (!mineOnly || t.assigned_to_id === userId))
  const canDrag = (t) => canManage || t.assigned_to_id === userId
  const reasonFor = (to) => (dragging ? moveBlockedReason({ todo: dragging, to, userId, canManage }) : '')

  function drop(to) {
    const todo = dragging
    setDragging(null)
    setHover('')
    if (!todo || todo.progress === to) return
    const reason = moveBlockedReason({ todo, to, userId, canManage })
    if (reason) return toast.error(reason)
    move.mutate({ id: todo.id, status: to })
  }

  return (
    <>
      <div className="toolbar">
        <select className="select" value={taskFilter} onChange={(e) => setTaskFilter(e.target.value)} aria-label="Filter by task">
          <option value="">All tasks</option>
          {tasks.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
        </select>
        <button className="toggle" aria-pressed={mineOnly} onClick={() => setMineOnly((m) => !m)}>Assigned to me</button>
        <span className="grow" />
        {canManage && (
          <button className="btn btn-primary btn-sm" disabled={!tasks.length} onClick={onCreate} title={tasks.length ? '' : 'Create a task first'}>
            New todo
          </button>
        )}
      </div>

      <div className="board">
        {STATUSES.map((lane) => {
          const items = visible.filter((t) => t.progress === lane.id)
          const state = dragging && dragging.progress !== lane.id ? (reasonFor(lane.id) ? 'no' : 'ok') : undefined
          return (
            <section
              key={lane.id}
              className="lane"
              data-status={lane.id}
              data-drop={hover === lane.id ? state : dragging ? (state === 'no' ? 'no' : undefined) : undefined}
              onDragOver={(e) => {
                // Accept every drop so a blocked move can explain itself with a message instead of silently bouncing.
                if (dragging) {
                  e.preventDefault()
                  setHover(lane.id)
                }
              }}
              onDragLeave={(e) => !e.currentTarget.contains(e.relatedTarget) && setHover('')}
              onDrop={(e) => {
                e.preventDefault()
                drop(lane.id)
              }}
              aria-label={`${lane.label}, ${items.length} todos`}
            >
              <div className="lane-head">
                <span className={`dot ${lane.id}`} />
                {lane.label}
                <span className="n">{items.length}</span>
              </div>
              <div className="lane-body">
                {items.map((t) => (
                  <TodoCard
                    key={t.id}
                    todo={t}
                    draggable={canDrag(t)}
                    dragging={dragging?.id === t.id}
                    onOpen={onOpen}
                    onDragStart={setDragging}
                    onDragEnd={() => {
                      setDragging(null)
                      setHover('')
                    }}
                  />
                ))}
                {!items.length && <div className="lane-empty">{lane.id === 'in_review' ? 'Nothing waiting for review' : 'Nothing here'}</div>}
              </div>
            </section>
          )
        })}
      </div>
    </>
  )
}
