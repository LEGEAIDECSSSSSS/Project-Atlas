import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api'
import { keys, useAction } from '../queries'
import { formatDate } from '../lib/format'
import { RoleChip } from '../ui/bits'
import { useToast } from '../ui/Toast'
import { monogram, orgTileStyle } from '../lib/format'

export default function InvitationList({ invitations }) {
  const toast = useToast()
  const navigate = useNavigate()
  const [pending, setPending] = useState(null)

  const accept = useAction((id) => api.post(`/me/invitations/${id}/accept`), [keys.orgs, keys.invitations], {
    onSuccess: (data) => {
      toast.success(`You joined ${data.organisation.name}.`)
      navigate(`/o/${data.organisation.id}`)
    },
    onError: (e) => toast.error(e.message),
  })
  const decline = useAction((id) => api.post(`/me/invitations/${id}/decline`), [keys.invitations], {
    onSuccess: () => toast.success('Invitation declined.'),
    onError: (e) => toast.error(e.message),
  })

  return (
    <div className="rows">
      {invitations.map((inv) => (
        <div key={inv.id} className="row" style={{ gridTemplateColumns: '42px minmax(0,1fr) auto' }}>
          <span className="org-tile" style={{ ...orgTileStyle(inv.organisation_name), opacity: 1 }}>
            {monogram(inv.organisation_name)}
          </span>
          <div>
            <div className="title">{inv.organisation_name}</div>
            <div className="meta">
              {inv.invited_by_name} invited you as <RoleChip role={inv.role} /> · expires {formatDate(inv.expires_at)}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-sm" disabled={pending === inv.id} onClick={() => { setPending(inv.id); decline.mutate(inv.id, { onSettled: () => setPending(null) }) }}>
              Decline
            </button>
            <button className="btn btn-primary btn-sm" disabled={pending === inv.id} onClick={() => { setPending(inv.id); accept.mutate(inv.id, { onSettled: () => setPending(null) }) }}>
              Accept
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
