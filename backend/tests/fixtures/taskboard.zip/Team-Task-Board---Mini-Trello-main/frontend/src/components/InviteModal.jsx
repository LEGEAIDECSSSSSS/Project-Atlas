import { useState } from 'react'
import { api } from '../api'
import { keys, useAction } from '../queries'
import { invitableRoles } from '../lib/rules'
import { normaliseEmail, suggestEmail, validateEmail } from '../lib/email'
import Field from '../ui/Field'
import Modal from '../ui/Modal'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

const ROLE_HELP = {
  member: 'Can see the teams they’re added to and work on todos assigned to them.',
  admin: 'Can create teams, invite members and remove regular members.',
  owner: 'Full control, including roles and renaming. Only owners can hand this out.',
}

export default function InviteModal({ orgId, role, onClose }) {
  const toast = useToast()
  const roles = invitableRoles(role)
  const [email, setEmail] = useState('')
  const [inviteRole, setInviteRole] = useState('member')
  const [emailError, setEmailError] = useState('')
  const invite = useAction((body) => api.post(`/orgs/${orgId}/invitations`, body), [keys.orgInvites(orgId)], {
    onSuccess: (inv) => {
      toast.success(`Invitation sent to ${inv.email}.`)
      onClose()
    },
  })
  const suggestion = suggestEmail(email)

  function submit() {
    const problem = validateEmail(email)
    setEmailError(problem)
    if (!problem) invite.mutate({ email: normaliseEmail(email), role: inviteRole })
  }

  return (
    <Modal
      title="Invite someone"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={invite.isPending} onClick={submit}>Send invitation</button>
        </>
      }
    >
      <p className="muted" style={{ marginBottom: 16 }}>
        They’ll get an email. If they already have an account they accept from their Invitations page; otherwise they sign up with this address first.
      </p>
      <Field label="Email address" error={emailError}>
        {(a) => (
          <input
            {...a}
            className="input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => email && setEmailError(validateEmail(email))}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
          />
        )}
      </Field>
      {suggestion && (
        <p className="suggest" style={{ marginTop: -8, marginBottom: 16 }}>
          Did you mean <button type="button" className="link" onClick={() => setEmail(suggestion)}>{suggestion}</button>?
        </p>
      )}
      <Field label="Role in this organisation" hint={ROLE_HELP[inviteRole]}>
        {(a) => (
          <select {...a} className="select" value={inviteRole} onChange={(e) => setInviteRole(e.target.value)}>
            {roles.map((r) => <option key={r} value={r}>{r[0].toUpperCase() + r.slice(1)}</option>)}
          </select>
        )}
      </Field>
      <p className="muted" style={{ fontSize: 'var(--t-s)' }}>Team leads are set per team, from the team’s Members tab.</p>
      <div style={{ marginTop: 12 }}><ErrorNotice error={invite.error} /></div>
    </Modal>
  )
}
