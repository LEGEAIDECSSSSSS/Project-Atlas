import { useEffect } from 'react'
import { Link, Outlet, useParams } from 'react-router-dom'
import { useOrg } from '../queries'
import { Empty, Loading } from '../ui/bits'

/** Resolves the organisation in the URL and the caller's role in it. Everything below depends on that role. */
export default function OrgLayout() {
  const { orgId } = useParams()
  const { data, isLoading, error } = useOrg(orgId)

  useEffect(() => {
    if (data) {
      try {
        localStorage.setItem('taskboard.lastOrg', String(orgId))
      } catch {
        /* storage unavailable */
      }
    }
  }, [data, orgId])

  if (isLoading) return <Loading />
  if (error || !data) {
    return (
      <Empty
        title="You don’t have access to this organisation"
        action={
          <Link to="/" className="btn btn-primary">
            Go to your organisations
          </Link>
        }
      >
        It may have been removed, or you may have left it. If you were invited, check your invitations.
      </Empty>
    )
  }
  return <Outlet context={{ orgId: Number(orgId), org: data.organisation, role: data.role }} />
}
