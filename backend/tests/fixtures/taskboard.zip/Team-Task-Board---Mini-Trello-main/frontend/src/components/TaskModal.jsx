import { useState } from 'react'
import { api } from '../api'
import { keys, useAction } from '../queries'
import { fromLocalInput, toLocalInput } from '../lib/format'
import Field from '../ui/Field'
import Modal from '../ui/Modal'
import Confirm from '../ui/Confirm'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function TaskModal({ orgId, teamId, task, onClose }) {
  const toast = useToast()
  const creating = !task
  const [form, setForm] = useState({ title: task?.title ?? '', description: task?.description ?? '', due: toLocalInput(task?.due_date) })
  const [confirmDelete, setConfirmDelete] = useState(false)
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))
  const refresh = [keys.tasks(orgId, teamId), keys.todos(orgId, teamId), keys.teams(orgId), keys.myTodos]

  const save = useAction(
    () =>
      creating
        ? api.post(`/orgs/${orgId}/teams/${teamId}/tasks`, { title: form.title.trim(), description: form.description.trim() || null, due_date: fromLocalInput(form.due) })
        : api.patch(`/orgs/${orgId}/tasks/${task.id}`, {
            title: form.title.trim(),
            description: form.description.trim(),
            ...(form.due ? { due_date: fromLocalInput(form.due) } : { clear_due_date: true }),
          }),
    refresh,
    { onSuccess: () => { toast.success(creating ? 'Task created.' : 'Task updated.'); onClose() } },
  )
  const del = useAction(() => api.del(`/orgs/${orgId}/tasks/${task.id}`), refresh, { onSuccess: () => toast.success('Task deleted.') })

  return (
    <Modal
      title={creating ? 'New task' : 'Edit task'}
      onClose={onClose}
      footer={
        <>
          {!creating && <button className="btn btn-quiet link-danger" style={{ marginRight: 'auto' }} onClick={() => setConfirmDelete(true)}>Delete</button>}
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={!form.title.trim() || save.isPending} onClick={() => save.mutate()}>
            {creating ? 'Create task' : 'Save changes'}
          </button>
        </>
      }
    >
      <p className="muted" style={{ marginBottom: 14 }}>A task is a body of work. Break it into todos and assign them to people on the team.</p>
      <Field label="Title">{(a) => <input {...a} className="input" maxLength={150} value={form.title} onChange={set('title')} />}</Field>
      <Field label="Description">{(a) => <textarea {...a} className="textarea" value={form.description} onChange={set('description')} />}</Field>
      <Field label="Due">{(a) => <input {...a} className="input" type="datetime-local" value={form.due} onChange={set('due')} />}</Field>
      <ErrorNotice error={save.error} />
      {confirmDelete && (
        <Confirm title="Delete this task?" message="Its todos are deleted too. This can’t be undone." confirmLabel="Delete task" onConfirm={async () => { await del.mutateAsync(); onClose() }} onClose={() => setConfirmDelete(false)} />
      )}
    </Modal>
  )
}
