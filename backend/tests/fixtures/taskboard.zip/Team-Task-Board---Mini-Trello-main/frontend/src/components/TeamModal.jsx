import { useState } from 'react'
import { api } from '../api'
import { useAuth } from '../auth'
import { keys, useAction, useMembers } from '../queries'
import Field from '../ui/Field'
import Modal from '../ui/Modal'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function TeamModal({ orgId, onClose, onCreated }) {
  const { user } = useAuth()
  const toast = useToast()
  const { data: members = [] } = useMembers(orgId)
  const [form, setForm] = useState({ name: '', description: '', lead: String(user.id) })
  const create = useAction(
    () => api.post(`/orgs/${orgId}/teams`, { name: form.name.trim(), description: form.description.trim() || null, lead_user_id: Number(form.lead) }),
    [keys.teams(orgId), keys.members(orgId)],
    {
      onSuccess: (team) => {
        toast.success(`Team “${team.name}” created.`)
        onCreated?.(team)
        onClose()
      },
    },
  )
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  return (
    <Modal
      title="Create a team"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={form.name.trim().length < 2 || create.isPending} onClick={() => create.mutate()}>
            Create team
          </button>
        </>
      }
    >
      <Field label="Team name">{(a) => <input {...a} className="input" maxLength={80} value={form.name} onChange={set('name')} />}</Field>
      <Field label="What does this team do?" hint="Optional.">{(a) => <textarea {...a} className="textarea" maxLength={2000} value={form.description} onChange={set('description')} />}</Field>
      <Field label="Team lead" hint="Leads manage the team’s tasks and approve finished work. Someone can lead one team and be a member of another.">
        {(a) => (
          <select {...a} className="select" value={form.lead} onChange={set('lead')}>
            {members.map((m) => (
              <option key={m.user_id} value={m.user_id}>{m.name}{m.user_id === user.id ? ' (you)' : ''}</option>
            ))}
          </select>
        )}
      </Field>
      <ErrorNotice error={create.error} />
    </Modal>
  )
}
