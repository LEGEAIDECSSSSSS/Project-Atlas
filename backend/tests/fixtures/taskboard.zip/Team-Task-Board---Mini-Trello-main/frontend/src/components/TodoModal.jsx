import { useState } from 'react'
import { api } from '../api'
import { keys, useAction } from '../queries'
import { moveBlockedReason } from '../lib/rules'
import { fromLocalInput, PRIORITY_LABEL, STATUSES, statusLabel, toLocalInput, formatDue } from '../lib/format'
import { useMoveTodo } from './Board'
import Field from '../ui/Field'
import Modal from '../ui/Modal'
import Confirm from '../ui/Confirm'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

const LANE_COLOUR = { todo: 'var(--s-todo)', in_progress: 'var(--s-progress)', in_review: 'var(--s-review)', completed: 'var(--s-done)' }

/** Create a todo (todo = null), edit one (managers), or view/move one (assignees). */
export default function TodoModal({ orgId, teamId, todo, tasks, members, canManage, userId, defaultTaskId, onClose }) {
  const toast = useToast()
  const move = useMoveTodo(orgId, teamId)
  const creating = !todo
  const editable = canManage
  const [form, setForm] = useState({
    title: todo?.title ?? '',
    description: todo?.description ?? '',
    task_id: String(todo?.task_id ?? defaultTaskId ?? tasks[0]?.id ?? ''),
    assigned_to_id: todo?.assigned_to_id ? String(todo.assigned_to_id) : '',
    priority: todo?.priority ?? 'medium',
    due: toLocalInput(todo?.due),
  })
  const [confirmDelete, setConfirmDelete] = useState(false)
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const refresh = [keys.todos(orgId, teamId), keys.tasks(orgId, teamId), keys.teams(orgId), keys.myTodos]
  const save = useAction(
    () => {
      const common = {
        title: form.title.trim(),
        description: form.description.trim() || null,
        priority: form.priority,
        due: fromLocalInput(form.due),
      }
      if (creating) {
        return api.post(`/orgs/${orgId}/tasks/${form.task_id}/todos`, { ...common, assigned_to_id: form.assigned_to_id ? Number(form.assigned_to_id) : null })
      }
      return api.patch(`/orgs/${orgId}/todos/${todo.id}`, {
        ...common,
        due: undefined,
        ...(form.due ? { due: common.due } : { clear_due: true }),
        ...(form.assigned_to_id ? { assigned_to_id: Number(form.assigned_to_id) } : { unassign: true }),
      })
    },
    refresh,
    { onSuccess: () => { toast.success(creating ? 'Todo created.' : 'Todo updated.'); onClose() } },
  )
  const del = useAction(() => api.del(`/orgs/${orgId}/todos/${todo.id}`), refresh, { onSuccess: () => toast.success('Todo deleted.') })

  const isAssignee = todo?.assigned_to_id === userId
  const hint =
    !todo ? '' :
    todo.progress === 'in_review' && canManage ? 'Review requested. Move it to Completed to approve, or back to In progress to ask for changes.' :
    todo.progress === 'in_review' ? 'Waiting for your team lead to review.' :
    todo.progress === 'in_progress' && isAssignee && !canManage ? 'When you’re done, send it to review. Your team lead marks it completed.' : ''

  return (
    <Modal
      wide
      title={creating ? 'New todo' : editable ? 'Todo' : todo.title}
      onClose={onClose}
      footer={
        <>
          {!creating && editable && <button className="btn btn-quiet link-danger" style={{ marginRight: 'auto' }} onClick={() => setConfirmDelete(true)}>Delete</button>}
          <button className="btn" onClick={onClose}>{editable ? 'Cancel' : 'Close'}</button>
          {editable && (
            <button className="btn btn-primary" disabled={!form.title.trim() || !form.task_id || save.isPending} onClick={() => save.mutate()}>
              {creating ? 'Create todo' : 'Save changes'}
            </button>
          )}
        </>
      }
    >
      {todo && (
        <div className="field">
          <span className="label">Status</span>
          <div className="status-steps" role="group" aria-label="Status">
            {STATUSES.map((s) => {
              const reason = moveBlockedReason({ todo, to: s.id, userId, canManage })
              return (
                <button
                  key={s.id}
                  style={{ '--lane-c': LANE_COLOUR[s.id] }}
                  aria-pressed={todo.progress === s.id}
                  disabled={!!reason || move.isPending}
                  title={reason}
                  onClick={() => {
                    if (todo.progress !== s.id) move.mutate({ id: todo.id, status: s.id }, { onSuccess: onClose })
                  }}
                >
                  <span className={`dot ${s.id}`} />
                  {s.label}
                </button>
              )
            })}
          </div>
          {hint && <span className="hint">{hint}</span>}
        </div>
      )}

      {editable ? (
        <>
          <Field label="Title">{(a) => <input {...a} className="input" maxLength={150} value={form.title} onChange={set('title')} />}</Field>
          <Field label="Details">{(a) => <textarea {...a} className="textarea" value={form.description} onChange={set('description')} />}</Field>
          <div className="field-row">
            <Field label="Task">
              {(a) => (
                <select {...a} className="select" value={form.task_id} onChange={set('task_id')} disabled={!creating}>
                  {tasks.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
                </select>
              )}
            </Field>
            <Field label="Assigned to">
              {(a) => (
                <select {...a} className="select" value={form.assigned_to_id} onChange={set('assigned_to_id')}>
                  <option value="">Unassigned</option>
                  {members.map((m) => <option key={m.user_id} value={m.user_id}>{m.name}</option>)}
                </select>
              )}
            </Field>
          </div>
          <div className="field-row">
            <Field label="Priority">
              {(a) => (
                <select {...a} className="select" value={form.priority} onChange={set('priority')}>
                  {Object.entries(PRIORITY_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              )}
            </Field>
            <Field label="Due">{(a) => <input {...a} className="input" type="datetime-local" value={form.due} onChange={set('due')} />}</Field>
          </div>
          <ErrorNotice error={save.error} />
        </>
      ) : (
        <dl style={{ margin: 0, display: 'grid', gridTemplateColumns: '110px 1fr', gap: '10px 16px' }}>
          <dt className="muted">Details</dt><dd style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{todo.description || '—'}</dd>
          <dt className="muted">Task</dt><dd style={{ margin: 0 }}>{todo.task_title}</dd>
          <dt className="muted">Assigned to</dt><dd style={{ margin: 0 }}>{todo.assigned_to_name || 'Unassigned'}</dd>
          <dt className="muted">Priority</dt><dd style={{ margin: 0 }}>{PRIORITY_LABEL[todo.priority]}</dd>
          <dt className="muted">Due</dt><dd style={{ margin: 0 }}>{todo.due ? formatDue(todo.due) : 'No due date'}{todo.is_late && ' (overdue)'}</dd>
          <dt className="muted">Status</dt><dd style={{ margin: 0 }}>{statusLabel(todo.progress)}</dd>
        </dl>
      )}

      {confirmDelete && <Confirm title="Delete this todo?" message="This can’t be undone." confirmLabel="Delete todo" onConfirm={async () => { await del.mutateAsync(); onClose() }} onClose={() => setConfirmDelete(false)} />}
    </Modal>
  )
}
