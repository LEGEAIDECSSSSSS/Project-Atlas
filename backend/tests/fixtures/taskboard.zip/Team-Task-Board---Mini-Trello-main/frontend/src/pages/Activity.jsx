import { useOutletContext } from 'react-router-dom'
import { useActivity } from '../queries'
import { isOrgAdmin } from '../lib/rules'
import { timeAgo } from '../lib/format'
import { Empty, ErrorNotice, Loading, PageHead } from '../ui/bits'

const SENTENCE = {
  'organisation.created': 'created the organisation',
  'organisation.renamed': 'renamed the organisation',
  'invitation.sent': 'sent an invitation',
  'invitation.revoked': 'revoked an invitation',
  'member.joined': 'joined',
  'member.left': 'left the organisation',
  'member.removed': 'removed a member',
  'member.role_changed': 'changed a role',
  'team.created': 'created a team',
  'team.deleted': 'deleted a team',
  'team.member_added': 'added someone to a team',
  'team.member_removed': 'removed someone from a team',
  'team.role_changed': 'changed a team role',
  'task.created': 'created a task',
  'task.deleted': 'deleted a task',
  'todo.created': 'created a todo',
  'todo.review_requested': 'sent a todo for review',
  'todo.approved': 'approved a todo',
  'todo.changes_requested': 'asked for changes on a todo',
  'todo.completed': 'completed a todo',
}

export default function Activity() {
  const { orgId, role } = useOutletContext()
  const admin = isOrgAdmin(role)
  const { data = [], isLoading, error } = useActivity(orgId, admin)

  if (!admin) return <Empty title="Admins only">The activity log is visible to owners and admins.</Empty>
  return (
    <>
      <PageHead title="Activity" sub="Who changed what in this organisation. Most recent first." />
      {isLoading ? (
        <Loading />
      ) : error ? (
        <ErrorNotice error={error} />
      ) : data.length ? (
        <ul className="timeline plain" style={{ maxWidth: 760 }}>
          {data.map((e) => (
            <li key={e.id}>
              <div><strong>{e.actor_name || 'Someone'}</strong> {SENTENCE[e.action] || e.action}</div>
              {e.detail && <div className="detail">{e.detail}</div>}
              <div className="when">{timeAgo(e.created_at)}</div>
            </li>
          ))}
        </ul>
      ) : (
        <Empty title="Nothing yet">Actions like invitations, role changes, and reviews will appear here.</Empty>
      )}
    </>
  )
}
