import { Link } from 'react-router-dom'
import { BrandMark } from '../ui/bits'
import { monogram, orgTileStyle } from '../lib/format'

const LEDGER = [
  { org: 'Acme Studio', note: 'Founded it', role: 'Owner' },
  { org: 'Northwind', note: 'Platform team', role: 'Team lead' },
  { org: 'Brightside', note: 'Freelance, design', role: 'Member' },
]

export default function AuthLayout({ children }) {
  return (
    <div className="auth">
      <section className="auth-brand">
        <Link to="/login" className="mark">
          <BrandMark /> TaskBoard
        </Link>
        <div>
          <h1>One account for every team you work with</h1>
          <p className="lede">
            Change jobs, take on a second one, or lead one team while joining another. Your organisations stay separate and your role in each is its own.
          </p>
        </div>
        <ul className="ledger" aria-label="Example: one person, three organisations">
          {LEDGER.map(({ org, note, role }) => (
            <li key={org}>
              <span className="org-tile" style={orgTileStyle(org)}>
                {monogram(org)}
              </span>
              <span>
                <strong>{org}</strong>
                <small>{note}</small>
              </span>
              <span className="chip">{role}</span>
            </li>
          ))}
        </ul>
      </section>
      <section className="auth-form-side">
        <div className="auth-card">{children}</div>
      </section>
    </div>
  )
}
