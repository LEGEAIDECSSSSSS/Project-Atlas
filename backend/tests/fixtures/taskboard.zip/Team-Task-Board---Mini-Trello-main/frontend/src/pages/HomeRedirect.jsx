import { Navigate } from 'react-router-dom'
import { useMyOrgs } from '../queries'
import { Loading } from '../ui/bits'

export default function HomeRedirect() {
  const { data: orgs, isLoading } = useMyOrgs()
  if (isLoading) return <Loading />
  if (!orgs?.length) return <Navigate to="/welcome" replace />
  let last = null
  try {
    last = localStorage.getItem('taskboard.lastOrg')
  } catch {
    /* storage unavailable */
  }
  const target = orgs.find((o) => String(o.organisation.id) === last) || orgs[0]
  return <Navigate to={`/o/${target.organisation.id}`} replace />
}
