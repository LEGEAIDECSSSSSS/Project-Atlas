import { useMyInvitations } from '../queries'
import InvitationList from '../components/InvitationList'
import { Empty, Loading, PageHead } from '../ui/bits'
import { useAuth } from '../auth'

export default function Invitations() {
  const { user } = useAuth()
  const { data = [], isLoading } = useMyInvitations()
  return (
    <>
      <PageHead title="Invitations" sub={`Organisations that have invited ${user.email}. Accepting adds the organisation to your rail without affecting the others.`} />
      {isLoading ? (
        <Loading />
      ) : data.length ? (
        <InvitationList invitations={data} />
      ) : (
        <Empty title="No pending invitations">
          Invitations are matched to your account’s email address. If someone invited a different address, ask them to invite {user.email}, or sign up with the address they used.
        </Empty>
      )}
    </>
  )
}
