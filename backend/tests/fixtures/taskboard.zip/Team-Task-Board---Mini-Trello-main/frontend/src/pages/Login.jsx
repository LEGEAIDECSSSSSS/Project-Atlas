import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import { normaliseEmail, validateEmail } from '../lib/email'
import AuthLayout from './AuthLayout'
import Field, { PasswordInput } from '../ui/Field'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const toast = useToast()
  const [params] = useSearchParams()
  const next = params.get('next')
  const [email, setEmail] = useState(params.get('email') || '')
  const [password, setPassword] = useState('')
  const [emailError, setEmailError] = useState('')
  const [error, setError] = useState(null)
  const [unverified, setUnverified] = useState(false)
  const [busy, setBusy] = useState(false)

  const carry = params.toString() ? `?${params.toString()}` : ''

  async function submit(event) {
    event.preventDefault()
    const problem = validateEmail(email)
    setEmailError(problem)
    if (problem) return
    setBusy(true)
    setError(null)
    setUnverified(false)
    try {
      await login(normaliseEmail(email), password)
      navigate(next && next.startsWith('/') ? next : '/', { replace: true })
    } catch (e) {
      if (e.code === 'email_not_verified') setUnverified(true)
      else setError(e)
    } finally {
      setBusy(false)
    }
  }

  async function resend() {
    try {
      await api.post('/auth/resend-verification', { email: normaliseEmail(email) })
      toast.success('Confirmation email sent. Check your inbox.')
    } catch (e) {
      toast.error(e.message)
    }
  }

  return (
    <AuthLayout>
      <h2>Welcome back</h2>
      <p className="lede">Log in to see your organisations and the work waiting for you.</p>
      <form onSubmit={submit} noValidate>
        <Field label="Email address" error={emailError}>
          {(a) => (
            <input
              {...a}
              className="input"
              type="email"
              autoComplete="email"
              autoFocus={!email}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onBlur={() => email && setEmailError(validateEmail(email))}
            />
          )}
        </Field>
        <Field label="Password">
          {(a) => (
            <PasswordInput {...a} autoComplete="current-password" autoFocus={!!email} value={password} onChange={(e) => setPassword(e.target.value)} />
          )}
        </Field>
        <div style={{ marginBottom: 16, textAlign: 'right' }}>
          <Link to="/forgot-password" className="link">
            Forgot your password?
          </Link>
        </div>
        {unverified && (
          <div className="notice warn" style={{ marginBottom: 16 }} role="alert">
            <MailCheck size={16} />
            <span>
              Confirm your email address first. We sent a link when you signed up.{' '}
              <button type="button" className="link" onClick={resend}>
                Send it again
              </button>
            </span>
          </div>
        )}
        <div style={{ marginBottom: 16 }}>
          <ErrorNotice error={error} />
        </div>
        <button className="btn btn-primary btn-block" disabled={busy || !password}>
          {busy ? 'Logging in…' : 'Log in'}
        </button>
      </form>
      <p className="foot">
        New here? <Link to={`/register${carry}`} className="link">Create an account</Link>
      </p>
    </AuthLayout>
  )
}

