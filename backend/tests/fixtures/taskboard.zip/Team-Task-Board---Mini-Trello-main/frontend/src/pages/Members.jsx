import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { UserPlus } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import { keys, useAction, useMembers, useOrgInvites } from '../queries'
import { isOrgAdmin } from '../lib/rules'
import { formatDate } from '../lib/format'
import InviteModal from '../components/InviteModal'
import Confirm from '../ui/Confirm'
import { Avatar, Loading, PageHead, RoleChip } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function Members() {
  const { orgId, role } = useOutletContext()
  const { user } = useAuth()
  const toast = useToast()
  const admin = isOrgAdmin(role)
  const { data: members = [], isLoading } = useMembers(orgId)
  const { data: invites = [] } = useOrgInvites(orgId, admin)
  const [inviting, setInviting] = useState(false)
  const [removing, setRemoving] = useState(null)

  const changeRole = useAction(({ userId, role: r }) => api.patch(`/orgs/${orgId}/members/${userId}`, { role: r }), [keys.members(orgId), keys.teams(orgId)], {
    onSuccess: () => toast.success('Role updated.'),
    onError: (e) => toast.error(e.message),
  })
  const remove = useAction((userId) => api.del(`/orgs/${orgId}/members/${userId}`), [keys.members(orgId), keys.teams(orgId), keys.activity(orgId)], {
    onSuccess: () => toast.success('Member removed.'),
    onError: (e) => toast.error(e.message),
  })
  const revoke = useAction((id) => api.del(`/orgs/${orgId}/invitations/${id}`), [keys.orgInvites(orgId)], {
    onSuccess: () => toast.success('Invitation revoked.'),
    onError: (e) => toast.error(e.message),
  })

  const canRemove = (m) => m.user_id !== user.id && (role === 'owner' || (role === 'admin' && m.role === 'member'))

  return (
    <>
      <PageHead
        title="Members"
        sub="Roles here apply to the whole organisation. Team leads are chosen inside each team."
        actions={admin && <button className="btn btn-primary" onClick={() => setInviting(true)}><UserPlus size={18} /> Invite someone</button>}
      />
      {isLoading ? (
        <Loading />
      ) : (
        <div className="rows">
          <div className="row row-member row-head">
            <span>Person</span><span>Role</span><span className="hide-sm">Teams</span><span className="hide-sm">Joined</span><span />
          </div>
          {members.map((m) => (
            <div key={m.user_id} className="row row-member">
              <div className="person">
                <Avatar name={m.name} />
                <div><strong>{m.name}{m.user_id === user.id && <span className="muted" style={{ display: 'inline', fontWeight: 400 }}> (you)</span>}</strong><span>{m.email}</span></div>
              </div>
              <div>
                {role === 'owner' ? (
                  <select className="select" style={{ minHeight: 34, padding: '4px 10px', width: 'auto' }} value={m.role} aria-label={`Role for ${m.name}`} onChange={(e) => changeRole.mutate({ userId: m.user_id, role: e.target.value })}>
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                    <option value="owner">Owner</option>
                  </select>
                ) : (
                  <RoleChip role={m.role} />
                )}
              </div>
              <span className="hide-sm">{m.team_count}</span>
              <span className="hide-sm meta">{formatDate(m.joined_at)}</span>
              <span className="cell-right">
                {canRemove(m) && <button className="btn btn-sm btn-quiet link-danger" onClick={() => setRemoving(m)}>Remove</button>}
              </span>
            </div>
          ))}
        </div>
      )}

      {admin && invites.length > 0 && (
        <section className="section">
          <div className="section-head"><h2>Pending invitations</h2></div>
          <div className="rows">
            {invites.map((inv) => (
              <div key={inv.id} className="row row-invite">
                <div className="person"><div><strong>{inv.email}</strong><span>Invited by {inv.invited_by_name}</span></div></div>
                <RoleChip role={inv.role} />
                <span className="hide-sm meta">Expires {formatDate(inv.expires_at)}</span>
                <span className="cell-right"><button className="btn btn-sm btn-quiet" onClick={() => revoke.mutate(inv.id)}>Revoke</button></span>
              </div>
            ))}
          </div>
        </section>
      )}

      {inviting && <InviteModal orgId={orgId} role={role} onClose={() => setInviting(false)} />}
      {removing && (
        <Confirm
          title={`Remove ${removing.name}?`}
          message="They lose access to this organisation and its teams. Their open todos become unassigned. Their history stays in the activity log, and they can be invited back later."
          confirmLabel="Remove member"
          onConfirm={() => remove.mutateAsync(removing.user_id)}
          onClose={() => setRemoving(null)}
        />
      )}
    </>
  )
}
