import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useMyTodos } from '../queries'
import { formatDue, monogram, orgTileStyle, statusLabel } from '../lib/format'
import { Empty, Loading, PageHead } from '../ui/bits'

export default function MyWork() {
  const { data = [], isLoading } = useMyTodos()
  const [showDone, setShowDone] = useState(false)
  const visible = data.filter((t) => showDone || t.progress !== 'completed')

  const groups = new Map()
  visible.forEach((t) => {
    if (!groups.has(t.organisation_id)) groups.set(t.organisation_id, { name: t.organisation_name, items: [] })
    groups.get(t.organisation_id).items.push(t)
  })
  const open = data.filter((t) => t.progress !== 'completed')
  const late = open.filter((t) => t.is_late).length

  return (
    <>
      <PageHead
        title="My work"
        sub="Everything assigned to you, across every organisation you belong to."
        actions={
          <button className="toggle" aria-pressed={showDone} onClick={() => setShowDone((s) => !s)}>
            Show completed
          </button>
        }
      />
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div className="glance" style={{ paddingTop: 0 }}>
            <div><strong>{open.length}</strong><span>open</span></div>
            <div><strong className={late ? 'warn' : ''}>{late}</strong><span>overdue</span></div>
            <div><strong>{groups.size}</strong><span>{groups.size === 1 ? 'organisation' : 'organisations'}</span></div>
          </div>
          {groups.size === 0 ? (
            <div style={{ marginTop: 28 }}>
              <Empty title="Nothing assigned to you">When a team lead assigns you a todo, it shows up here, whichever organisation it’s in.</Empty>
            </div>
          ) : (
            [...groups.entries()].map(([orgId, group]) => (
              <section key={orgId} className="section" style={{ marginTop: 32 }}>
                <div className="section-head" style={{ justifyContent: 'flex-start', alignItems: 'center', gap: 12 }}>
                  <span className="org-tile" style={{ ...orgTileStyle(group.name), opacity: 1, width: 32, height: 32, fontSize: '0.75rem', borderRadius: 9 }}>{monogram(group.name)}</span>
                  <h2>{group.name}</h2>
                </div>
                <div className="rows">
                  {group.items.map((t) => (
                    <Link key={t.id} to={`/o/${t.organisation_id}/teams/${t.team_id}`} className="row link-row work-row">
                      <span className={`dot ${t.progress}`} title={statusLabel(t.progress)} />
                      <div style={{ minWidth: 0 }}>
                        <div className="title" style={{ overflowWrap: 'anywhere' }}>{t.title}</div>
                        <div className="meta">{t.team_name} · {t.task_title} · {statusLabel(t.progress)}</div>
                      </div>
                      {t.is_late ? <span className="chip late">Overdue</span> : <span />}
                      <span className="meta nowrap">{t.due ? formatDue(t.due) : 'No due date'}</span>
                    </Link>
                  ))}
                </div>
              </section>
            ))
          )}
        </>
      )}
    </>
  )
}
