import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { api } from '../api'
import { keys, useAction, useMyInvitations } from '../queries'
import Field from '../ui/Field'
import { ErrorNotice, PageHead } from '../ui/bits'

export default function NewOrg() {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const { data: invitations = [] } = useMyInvitations()
  const create = useAction((n) => api.post('/orgs', { name: n }), [keys.orgs], {
    onSuccess: (data) => navigate(`/o/${data.organisation.id}`),
  })

  return (
    <>
      <PageHead title="Create an organisation" sub="You’ll be the owner. Everything inside it (teams, tasks, members) stays separate from your other organisations." />
      <form
        style={{ maxWidth: 460 }}
        onSubmit={(e) => {
          e.preventDefault()
          if (name.trim().length >= 2) create.mutate(name.trim())
        }}
      >
        <Field label="Organisation name" hint="Your company, school, or project. You can rename it later.">
          {(a) => <input {...a} className="input" autoFocus maxLength={100} value={name} onChange={(e) => setName(e.target.value)} />}
        </Field>
        <div style={{ marginBottom: 16 }}>
          <ErrorNotice error={create.error} />
        </div>
        <button className="btn btn-primary" disabled={name.trim().length < 2 || create.isPending}>
          {create.isPending ? 'Creating…' : 'Create organisation'}
        </button>
      </form>
      {invitations.length > 0 && (
        <p className="muted" style={{ marginTop: 28 }}>
          Looking to join an existing organisation instead? You have {invitations.length} pending{' '}
          <Link to="/invitations" className="link">invitation{invitations.length > 1 ? 's' : ''}</Link>.
        </p>
      )}
    </>
  )
}
