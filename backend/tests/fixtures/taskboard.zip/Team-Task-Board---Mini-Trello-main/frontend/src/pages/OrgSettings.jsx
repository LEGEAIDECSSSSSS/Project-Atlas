import { useState } from 'react'
import { useNavigate, useOutletContext } from 'react-router-dom'
import { api } from '../api'
import { keys, useAction } from '../queries'
import { ROLE_LABEL } from '../lib/format'
import Field from '../ui/Field'
import Confirm from '../ui/Confirm'
import { ErrorNotice, PageHead } from '../ui/bits'
import { useToast } from '../ui/Toast'
import { useQueryClient } from '@tanstack/react-query'

export default function OrgSettings() {
  const { orgId, org, role } = useOutletContext()
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [name, setName] = useState(org.name)
  const [leaving, setLeaving] = useState(false)

  const rename = useAction((n) => api.patch(`/orgs/${orgId}`, { name: n }), [keys.org(orgId), keys.orgs], {
    onSuccess: () => toast.success('Organisation renamed.'),
  })
  const leave = useAction(() => api.post(`/orgs/${orgId}/leave`), [keys.orgs, keys.myTodos], {
    onSuccess: () => {
      queryClient.removeQueries({ queryKey: keys.org(orgId) })
      toast.success(`You left ${org.name}.`)
      navigate('/', { replace: true })
    },
    onError: (e) => toast.error(e.message),
  })

  return (
    <>
      <PageHead title="Settings" sub={`You are ${ROLE_LABEL[role].toLowerCase()} of ${org.name}.`} />
      <form
        style={{ maxWidth: 460 }}
        onSubmit={(e) => {
          e.preventDefault()
          rename.mutate(name.trim())
        }}
      >
        <Field label="Organisation name" hint={role === 'owner' ? '' : 'Only owners can rename the organisation.'}>
          {(a) => <input {...a} className="input" value={name} maxLength={100} disabled={role !== 'owner'} onChange={(e) => setName(e.target.value)} />}
        </Field>
        <ErrorNotice error={rename.error} />
        {role === 'owner' && (
          <button className="btn btn-primary" style={{ marginTop: 12 }} disabled={name.trim().length < 2 || name.trim() === org.name || rename.isPending}>
            Save name
          </button>
        )}
      </form>

      <div className="danger-zone">
        <h3>Leave this organisation</h3>
        <p>
          Changed jobs? You’ll lose access to {org.name} and be removed from its teams, and your open todos here become unassigned. Your other organisations aren’t affected.
          {role === 'owner' && ' If you’re the only owner, make someone else an owner first.'}
        </p>
        <button className="btn btn-danger" onClick={() => setLeaving(true)}>Leave {org.name}</button>
      </div>
      {leaving && (
        <Confirm title={`Leave ${org.name}?`} message="You can only come back if someone invites you again." confirmLabel="Leave organisation" onConfirm={() => leave.mutateAsync()} onClose={() => setLeaving(false)} />
      )}
    </>
  )
}
