import { Link, useOutletContext } from 'react-router-dom'
import { TriangleAlert } from 'lucide-react'
import { useMembers, useMyTodos, useOrgInvites, useTeams } from '../queries'
import { isOrgAdmin } from '../lib/rules'
import { formatDue, statusLabel } from '../lib/format'
import { Empty, Loading, PageHead } from '../ui/bits'

export default function Overview() {
  const { orgId, org, role } = useOutletContext()
  const admin = isOrgAdmin(role)
  const { data: teams = [], isLoading } = useTeams(orgId)
  const { data: members = [] } = useMembers(orgId)
  const { data: myTodos = [] } = useMyTodos()
  const { data: invites = [] } = useOrgInvites(orgId, admin)

  const mine = myTodos.filter((t) => t.organisation_id === orgId && t.progress !== 'completed')
  const late = mine.filter((t) => t.is_late).length
  const leaderless = teams.filter((t) => t.leads.length === 0)

  if (isLoading) return <Loading />

  return (
    <>
      <PageHead title={org.name} sub={admin ? 'Set up teams, invite people, and keep an eye on what needs attention.' : 'Your teams and the work assigned to you here.'} />
      <div className="glance">
        <div><strong>{mine.length}</strong><span>your open todos</span></div>
        <div><strong className={late ? 'warn' : ''}>{late}</strong><span>overdue</span></div>
        <div><strong>{teams.length}</strong><span>{admin ? 'teams' : 'your teams'}</span></div>
        <div><strong>{members.length}</strong><span>people</span></div>
        {admin && <div><strong>{invites.length}</strong><span>pending invitations</span></div>}
      </div>

      {admin && leaderless.length > 0 && (
        <div className="notice warn" style={{ marginTop: 28 }}>
          <TriangleAlert size={16} />
          <span>
            {leaderless.map((t) => t.name).join(', ')} {leaderless.length === 1 ? 'has' : 'have'} no team lead. Open the team’s Members tab to appoint one.
          </span>
        </div>
      )}

      <section className="section">
        <div className="section-head">
          <h2>Your work here</h2>
          <Link to="/my-work" className="link">All organisations</Link>
        </div>
        {mine.length ? (
          <div className="rows">
            {mine.slice(0, 8).map((t) => (
              <Link key={t.id} to={`/o/${orgId}/teams/${t.team_id}`} className="row link-row work-row">
                <span className={`dot ${t.progress}`} />
                <div style={{ minWidth: 0 }}>
                  <div className="title">{t.title}</div>
                  <div className="meta">{t.team_name} · {statusLabel(t.progress)}</div>
                </div>
                {t.is_late ? <span className="chip late">Overdue</span> : <span />}
                <span className="meta nowrap">{t.due ? formatDue(t.due) : ''}</span>
              </Link>
            ))}
          </div>
        ) : (
          <Empty title="You’re all caught up">Nothing is assigned to you in {org.name} right now.</Empty>
        )}
      </section>

      <section className="section">
        <div className="section-head">
          <h2>{admin ? 'Teams' : 'Your teams'}</h2>
          <Link to={`/o/${orgId}/teams`} className="link">{admin ? 'Manage teams' : 'View all'}</Link>
        </div>
        {teams.length ? (
          <div className="rows">
            {teams.slice(0, 6).map((t) => (
              <Link key={t.id} to={`/o/${orgId}/teams/${t.id}`} className="row link-row" style={{ gridTemplateColumns: 'minmax(0,1fr) auto auto' }}>
                <span className="title">{t.name}</span>
                <span className="meta">{t.open_todo_count} open{t.overdue_todo_count ? ` · ${t.overdue_todo_count} overdue` : ''}</span>
                {t.my_role === 'lead' ? <span className="chip lead">Team lead</span> : t.my_role ? <span className="chip">Member</span> : <span />}
              </Link>
            ))}
          </div>
        ) : (
          <Empty title={admin ? 'No teams yet' : 'You’re not on a team yet'}>
            {admin ? 'Create a team and pick a lead to get the first board going.' : 'An admin or team lead will add you to a team.'}
          </Empty>
        )}
      </section>
    </>
  )
}
