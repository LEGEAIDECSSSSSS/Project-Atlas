import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { api } from '../api'
import { normaliseEmail, passwordChecks, validateEmail } from '../lib/email'
import AuthLayout from './AuthLayout'
import Field, { PasswordInput } from '../ui/Field'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

export function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [emailError, setEmailError] = useState('')
  const [error, setError] = useState(null)
  const [sent, setSent] = useState(false)

  async function submit(event) {
    event.preventDefault()
    const problem = validateEmail(email)
    setEmailError(problem)
    if (problem) return
    try {
      await api.post('/auth/forgot-password', { email: normaliseEmail(email) })
      setSent(true)
    } catch (e) {
      setError(e)
    }
  }

  if (sent) {
    return (
      <AuthLayout>
        <div className="big-icon">
          <MailCheck size={26} />
        </div>
        <h2>Check your inbox</h2>
        <p className="lede">If an account exists for {normaliseEmail(email)}, a link to choose a new password is on its way. It works for an hour.</p>
        <Link to="/login" className="btn btn-block">
          Back to log in
        </Link>
      </AuthLayout>
    )
  }

  return (
    <AuthLayout>
      <h2>Reset your password</h2>
      <p className="lede">Enter the email you signed up with and we’ll send you a link.</p>
      <form onSubmit={submit} noValidate>
        <Field label="Email address" error={emailError}>
          {(a) => <input {...a} className="input" type="email" autoComplete="email" autoFocus value={email} onChange={(e) => setEmail(e.target.value)} />}
        </Field>
        <div style={{ marginBottom: 16 }}>
          <ErrorNotice error={error} />
        </div>
        <button className="btn btn-primary btn-block">Send reset link</button>
      </form>
      <p className="foot">
        <Link to="/login" className="link">Back to log in</Link>
      </p>
    </AuthLayout>
  )
}

export function ResetPassword() {
  const [params] = useSearchParams()
  const token = params.get('token') || ''
  const navigate = useNavigate()
  const toast = useToast()
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const checks = passwordChecks(password)

  async function submit(event) {
    event.preventDefault()
    setError(null)
    try {
      await api.post('/auth/reset-password', { token, password })
      toast.success('Password changed. Log in with your new password.')
      navigate('/login', { replace: true })
    } catch (e) {
      setError(e)
    }
  }

  return (
    <AuthLayout>
      <h2>Choose a new password</h2>
      <p className="lede">You’ll be logged out of every device once it’s changed.</p>
      <form onSubmit={submit}>
        <Field label="New password">
          {(a) => <PasswordInput {...a} autoComplete="new-password" autoFocus value={password} onChange={(e) => setPassword(e.target.value)} />}
        </Field>
        <div className="checks" style={{ marginTop: -8, marginBottom: 18 }}>
          {checks.map((c) => (
            <span key={c.label} data-ok={c.ok}>
              {c.ok ? '✓' : '○'} {c.label}
            </span>
          ))}
        </div>
        <div style={{ marginBottom: 16 }}>
          <ErrorNotice error={error} />
        </div>
        <button className="btn btn-primary btn-block" disabled={!checks.every((c) => c.ok) || !token}>
          Change password
        </button>
      </form>
    </AuthLayout>
  )
}
