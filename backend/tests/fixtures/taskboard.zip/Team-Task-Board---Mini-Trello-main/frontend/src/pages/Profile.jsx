import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api'
import { useAuth } from '../auth'
import { keys, useAction, useMyOrgs } from '../queries'
import { passwordChecks } from '../lib/email'
import { monogram, orgTileStyle } from '../lib/format'
import Field, { PasswordInput } from '../ui/Field'
import { ErrorNotice, PageHead, RoleChip } from '../ui/bits'
import { useQueryClient } from '@tanstack/react-query'
import { useToast } from '../ui/Toast'

export default function Profile() {
  const { user } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const { data: orgs = [] } = useMyOrgs()
  const [name, setName] = useState(user.name)
  const [pw, setPw] = useState({ current: '', next: '' })
  const checks = passwordChecks(pw.next)

  const rename = useAction((n) => api.patch('/me', { name: n }), [], {
    onSuccess: (me) => {
      queryClient.setQueryData(['me'], me)
      queryClient.invalidateQueries({ queryKey: ['members'] })
      toast.success('Name updated.')
    },
  })
  const change = useAction((body) => api.post('/auth/change-password', body), [], {
    onSuccess: () => {
      setPw({ current: '', next: '' })
      toast.success('Password changed. Your other devices were logged out.')
    },
  })

  return (
    <>
      <PageHead title="Your profile" sub="One identity across every organisation you belong to." />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px 56px', maxWidth: 940 }}>
        <section>
          <h2 style={{ fontSize: 'var(--t-xl)', marginBottom: 14 }}>Details</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              rename.mutate(name.trim())
            }}
          >
            <Field label="Full name">{(a) => <input {...a} className="input" value={name} maxLength={100} onChange={(e) => setName(e.target.value)} />}</Field>
            <Field label="Email address" hint={user.email_verified ? 'Confirmed.' : 'Not confirmed yet.'}>
              {(a) => <input {...a} className="input" value={user.email} readOnly disabled />}
            </Field>
            <ErrorNotice error={rename.error} />
            <button className="btn btn-primary" style={{ marginTop: 12 }} disabled={!name.trim() || name.trim() === user.name || rename.isPending}>
              Save name
            </button>
          </form>
        </section>

        <section>
          <h2 style={{ fontSize: 'var(--t-xl)', marginBottom: 14 }}>Password</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              change.mutate({ current_password: pw.current, new_password: pw.next })
            }}
          >
            <Field label="Current password">
              {(a) => <PasswordInput {...a} autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />}
            </Field>
            <Field label="New password">
              {(a) => <PasswordInput {...a} autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />}
            </Field>
            <div className="checks" style={{ marginTop: -8, marginBottom: 16 }}>
              {checks.map((c) => (
                <span key={c.label} data-ok={c.ok}>{c.ok ? '✓' : '○'} {c.label}</span>
              ))}
            </div>
            <ErrorNotice error={change.error} />
            <button className="btn btn-primary" style={{ marginTop: 12 }} disabled={!pw.current || !checks.every((c) => c.ok) || change.isPending}>
              Change password
            </button>
          </form>
        </section>
      </div>

      <section className="section">
        <div className="section-head">
          <h2>Your organisations</h2>
        </div>
        <div className="rows">
          {orgs.map(({ organisation, role }) => (
            <Link key={organisation.id} to={`/o/${organisation.id}`} className="row link-row" style={{ gridTemplateColumns: '42px 1fr auto' }}>
              <span className="org-tile" style={{ ...orgTileStyle(organisation.name), opacity: 1 }}>{monogram(organisation.name)}</span>
              <span className="title">{organisation.name}</span>
              <RoleChip role={role} />
            </Link>
          ))}
        </div>
      </section>
    </>
  )
}
