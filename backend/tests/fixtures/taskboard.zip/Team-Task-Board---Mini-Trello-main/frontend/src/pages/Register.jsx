import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { api } from '../api'
import { normaliseEmail, passwordChecks, suggestEmail, validateEmail } from '../lib/email'
import AuthLayout from './AuthLayout'
import Field, { PasswordInput } from '../ui/Field'
import { ErrorNotice } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function Register() {
  const toast = useToast()
  const [params] = useSearchParams()
  const [form, setForm] = useState({ name: '', email: params.get('email') || '', password: '' })
  const [errors, setErrors] = useState({})
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)
  const [sentTo, setSentTo] = useState('')

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))
  const suggestion = suggestEmail(form.email)
  const checks = passwordChecks(form.password)
  const carry = params.toString() ? `?${params.toString()}` : ''

  async function submit(event) {
    event.preventDefault()
    const next = {
      name: form.name.trim() ? '' : 'Enter your name.',
      email: validateEmail(form.email),
      password: checks.every((c) => c.ok) ? '' : 'Choose a password that meets all three requirements.',
    }
    setErrors(next)
    if (Object.values(next).some(Boolean)) return
    setBusy(true)
    setError(null)
    try {
      await api.post('/auth/register', { name: form.name.trim(), email: normaliseEmail(form.email), password: form.password })
      setSentTo(normaliseEmail(form.email))
    } catch (e) {
      if (e.fields && Object.keys(e.fields).length) setErrors(e.fields)
      else setError(e)
    } finally {
      setBusy(false)
    }
  }

  async function resend() {
    try {
      await api.post('/auth/resend-verification', { email: sentTo })
      toast.success('Another email is on its way.')
    } catch (e) {
      toast.error(e.message)
    }
  }

  if (sentTo) {
    return (
      <AuthLayout>
        <div className="big-icon">
          <MailCheck size={26} />
        </div>
        <h2>Check your inbox</h2>
        <p className="lede">
          We sent a confirmation link to <strong>{sentTo}</strong>. Open it to activate your account, then log in. The link works for 24 hours.
        </p>
        <p className="foot" style={{ marginTop: 0 }}>
          Nothing arrived? Check spam, or{' '}
          <button className="link" onClick={resend}>
            send it again
          </button>
          . Wrong address?{' '}
          <button className="link" onClick={() => setSentTo('')}>
            Start over
          </button>
          .
        </p>
        <p className="foot">
          <Link to={`/login${carry}`} className="link">Go to log in</Link>
        </p>
      </AuthLayout>
    )
  }

  return (
    <AuthLayout>
      <h2>Create your account</h2>
      <p className="lede">It’s just you at this stage. You’ll create or join an organisation next.</p>
      <form onSubmit={submit} noValidate>
        <Field label="Full name" error={errors.name}>
          {(a) => <input {...a} className="input" autoComplete="name" autoFocus value={form.name} onChange={set('name')} />}
        </Field>
        <Field label="Work or personal email" error={errors.email} hint="We’ll email a link to confirm it’s yours.">
          {(a) => (
            <input
              {...a}
              className="input"
              type="email"
              autoComplete="email"
              value={form.email}
              onChange={set('email')}
              onBlur={() => form.email && setErrors((er) => ({ ...er, email: validateEmail(form.email) }))}
            />
          )}
        </Field>
        {suggestion && !errors.email && (
          <p className="suggest" style={{ marginTop: -8, marginBottom: 16 }}>
            Did you mean{' '}
            <button type="button" className="link" onClick={() => setForm((f) => ({ ...f, email: suggestion }))}>
              {suggestion}
            </button>
            ?
          </p>
        )}
        <Field label="Password" error={errors.password}>
          {(a) => <PasswordInput {...a} autoComplete="new-password" value={form.password} onChange={set('password')} />}
        </Field>
        <div className="checks" style={{ marginTop: -8, marginBottom: 18 }}>
          {checks.map((c) => (
            <span key={c.label} data-ok={c.ok}>
              {c.ok ? '✓' : '○'} {c.label}
            </span>
          ))}
        </div>
        <div style={{ marginBottom: 16 }}>
          <ErrorNotice error={error} />
        </div>
        <button className="btn btn-primary btn-block" disabled={busy}>
          {busy ? 'Creating account…' : 'Create account'}
        </button>
      </form>
      <p className="foot">
        Already registered? <Link to={`/login${carry}`} className="link">Log in</Link>
      </p>
    </AuthLayout>
  )
}
