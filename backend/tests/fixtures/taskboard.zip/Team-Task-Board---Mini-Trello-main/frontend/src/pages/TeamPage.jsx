import { useState } from 'react'
import { Link, useNavigate, useOutletContext, useParams, useSearchParams } from 'react-router-dom'
import { ChevronLeft, Pencil, Plus, UserPlus } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import { keys, useAction, useMembers, useTasks, useTeam, useTodos } from '../queries'
import { isOrgAdmin } from '../lib/rules'
import { formatDue } from '../lib/format'
import Board from '../components/Board'
import TodoModal from '../components/TodoModal'
import TaskModal from '../components/TaskModal'
import Field from '../ui/Field'
import Modal from '../ui/Modal'
import Confirm from '../ui/Confirm'
import { Avatar, Empty, ErrorNotice, Loading, RoleChip } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function TeamPage() {
  const { orgId, role } = useOutletContext()
  const { teamId } = useParams()
  const { user } = useAuth()
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') || 'board'
  const { data: team, isLoading, error } = useTeam(orgId, teamId)
  const { data: tasks = [] } = useTasks(orgId, teamId)
  const { data: todos = [] } = useTodos(orgId, teamId)

  const [todoModal, setTodoModal] = useState(null) // { todo?, taskId? }
  const [taskModal, setTaskModal] = useState(null) // { task? }
  const [editing, setEditing] = useState(false)

  if (isLoading) return <Loading />
  if (error || !team) {
    return (
      <Empty title="You can’t open this team" action={<Link to={`/o/${orgId}/teams`} className="btn btn-primary">Back to teams</Link>}>
        {error?.message || 'It may not exist, or you may not be a member of it.'}
      </Empty>
    )
  }

  const canManage = team.can_manage
  const setTab = (t) => setParams(t === 'board' ? {} : { tab: t })
  const tabs = [['board', 'Board'], ['tasks', `Tasks (${tasks.length})`], ['members', `Members (${team.members.length})`]]

  return (
    <>
      <Link to={`/o/${orgId}/teams`} className="link" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 14, textDecoration: 'none' }}>
        <ChevronLeft size={16} /> Teams
      </Link>
      <div className="page-head">
        <div>
          <h1>{team.name}</h1>
          <p className="sub">
            {team.description && <>{team.description}<br /></>}
            <span className="muted">
              {team.leads.length ? `Led by ${team.leads.map((l) => l.name).join(' and ')}` : 'No team lead yet'}
              {team.my_role === 'lead' ? ' (you)' : ''}
            </span>
          </p>
        </div>
        <div className="actions">
          {canManage && <button className="btn" onClick={() => setEditing(true)}><Pencil size={16} /> Edit team</button>}
          {canManage && <button className="btn btn-primary" onClick={() => setTaskModal({})}><Plus size={18} /> New task</button>}
        </div>
      </div>

      <div className="tabs" role="tablist">
        {tabs.map(([id, label]) => (
          <button key={id} role="tab" className="tab" aria-selected={tab === id} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>

      {tab === 'board' &&
        (tasks.length === 0 ? (
          <Empty title="No tasks yet" action={canManage && <button className="btn btn-primary" onClick={() => setTaskModal({})}>Create the first task</button>}>
            {canManage ? 'Start with a task, such as “Launch the new website”, then add todos under it and assign them.' : 'Your team lead will add tasks and assign you todos. They appear here.'}
          </Empty>
        ) : (
          <Board
            orgId={orgId}
            teamId={teamId}
            todos={todos}
            tasks={tasks}
            canManage={canManage}
            userId={user.id}
            onOpen={(todo) => setTodoModal({ todo })}
            onCreate={() => setTodoModal({})}
          />
        ))}

      {tab === 'tasks' && <TasksTab tasks={tasks} canManage={canManage} onEdit={(task) => setTaskModal({ task })} onAddTodo={(taskId) => setTodoModal({ taskId })} onNew={() => setTaskModal({})} />}
      {tab === 'members' && <MembersTab orgId={orgId} team={team} orgRole={role} userId={user.id} />}

      {todoModal && (
        <TodoModal
          orgId={orgId}
          teamId={teamId}
          todo={todoModal.todo}
          defaultTaskId={todoModal.taskId}
          tasks={tasks}
          members={team.members}
          canManage={canManage}
          userId={user.id}
          onClose={() => setTodoModal(null)}
        />
      )}
      {taskModal && <TaskModal orgId={orgId} teamId={teamId} task={taskModal.task} onClose={() => setTaskModal(null)} />}
      {editing && <EditTeamModal orgId={orgId} team={team} onClose={() => setEditing(false)} />}
    </>
  )
}

function TasksTab({ tasks, canManage, onEdit, onAddTodo, onNew }) {
  if (!tasks.length) {
    return (
      <Empty title="No tasks yet" action={canManage && <button className="btn btn-primary" onClick={onNew}>New task</button>}>
        Tasks group related todos so you can see how far along a piece of work is.
      </Empty>
    )
  }
  return (
    <div className="rows">
      {tasks.map((t) => {
        const pct = t.todo_count ? Math.round((t.done_count / t.todo_count) * 100) : 0
        return (
          <div key={t.id} className="row" style={{ gridTemplateColumns: 'minmax(0,2fr) minmax(120px,1fr) 120px auto' }}>
            <div style={{ minWidth: 0 }}>
              <div className="title">{t.title}</div>
              {t.description && <div className="meta" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.description}</div>}
            </div>
            <div>
              <div className="progress" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}><i style={{ width: `${pct}%` }} /></div>
              <div className="meta" style={{ marginTop: 4 }}>{t.done_count} of {t.todo_count} done</div>
            </div>
            <span className="meta hide-sm">{t.due_date ? `Due ${formatDue(t.due_date)}` : 'No due date'}</span>
            {canManage ? (
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-sm" onClick={() => onAddTodo(t.id)}>Add todo</button>
                <button className="btn btn-sm btn-quiet" onClick={() => onEdit(t)}>Edit</button>
              </div>
            ) : <span />}
          </div>
        )
      })}
    </div>
  )
}

function MembersTab({ orgId, team, orgRole, userId }) {
  const toast = useToast()
  const navigate = useNavigate()
  const admin = isOrgAdmin(orgRole)
  const [adding, setAdding] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const base = `/orgs/${orgId}/teams/${team.id}`
  const refresh = [keys.team(orgId, team.id), keys.teams(orgId), keys.todos(orgId, team.id), keys.myTodos, keys.members(orgId)]

  const setRole = useAction(({ id, role }) => api.patch(`${base}/members/${id}`, { role }), refresh, {
    onSuccess: () => toast.success('Team role updated.'),
    onError: (e) => toast.error(e.message),
  })
  const remove = useAction((id) => api.del(`${base}/members/${id}`), refresh, {
    onSuccess: (_d, id) => {
      toast.success('Removed from the team.')
      if (id === userId && !admin) navigate(`/o/${orgId}/teams`)
    },
    onError: (e) => toast.error(e.message),
  })
  const deleteTeam = useAction(() => api.del(`/orgs/${orgId}/teams/${team.id}`), [keys.teams(orgId), keys.myTodos], {
    onSuccess: () => { toast.success('Team deleted.'); navigate(`/o/${orgId}/teams`) },
  })

  return (
    <>
      {team.can_manage && (
        <div style={{ marginBottom: 16 }}>
          <button className="btn btn-primary btn-sm" onClick={() => setAdding(true)}><UserPlus size={16} /> Add member</button>
        </div>
      )}
      <div className="rows">
        {team.members.map((m) => (
          <div key={m.user_id} className="row" style={{ gridTemplateColumns: 'minmax(0,2fr) 150px auto' }}>
            <div className="person">
              <Avatar name={m.name} />
              <div><strong>{m.name}{m.user_id === userId && <span className="muted" style={{ fontWeight: 400 }}> (you)</span>}</strong><span>{m.email}</span></div>
            </div>
            {team.can_manage ? (
              <select className="select" style={{ minHeight: 34, padding: '4px 10px', width: 'auto' }} value={m.role} aria-label={`Team role for ${m.name}`} onChange={(e) => setRole.mutate({ id: m.user_id, role: e.target.value })}>
                <option value="member">Member</option>
                <option value="lead">Team lead</option>
              </select>
            ) : <RoleChip role={m.role} />}
            <span className="cell-right">
              {team.can_manage && <button className="btn btn-sm btn-quiet link-danger" onClick={() => remove.mutate(m.user_id)}>Remove</button>}
            </span>
          </div>
        ))}
      </div>
      <p className="muted" style={{ marginTop: 14, maxWidth: '64ch' }}>
        Team roles only apply to this team. A team lead here can be an ordinary member of another team, or of another organisation.
      </p>

      {admin && (
        <div className="danger-zone">
          <h3>Delete this team</h3>
          <p>Removes the team with all of its tasks and todos. This can’t be undone.</p>
          <button className="btn btn-danger" onClick={() => setDeleting(true)}>Delete team</button>
        </div>
      )}
      {adding && <AddMemberModal orgId={orgId} team={team} onClose={() => setAdding(false)} refresh={refresh} />}
      {deleting && <Confirm title={`Delete ${team.name}?`} message="All of its tasks and todos are deleted with it." confirmLabel="Delete team" onConfirm={() => deleteTeam.mutateAsync()} onClose={() => setDeleting(false)} />}
    </>
  )
}

function AddMemberModal({ orgId, team, onClose, refresh }) {
  const toast = useToast()
  const { data: orgMembers = [] } = useMembers(orgId)
  const onTeam = new Set(team.members.map((m) => m.user_id))
  const candidates = orgMembers.filter((m) => !onTeam.has(m.user_id))
  const [userId, setUserId] = useState('')
  const [role, setRole] = useState('member')
  const add = useAction(() => api.post(`/orgs/${orgId}/teams/${team.id}/members`, { user_id: Number(userId), role }), refresh, {
    onSuccess: () => { toast.success('Added to the team.'); onClose() },
  })

  return (
    <Modal
      title="Add a team member"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={!userId || add.isPending} onClick={() => add.mutate()}>Add to team</button>
        </>
      }
    >
      {candidates.length === 0 ? (
        <p className="muted">Everyone in the organisation is already on this team. To add someone new, invite them to the organisation first from Members.</p>
      ) : (
        <>
          <Field label="Person" hint="Only people already in this organisation can join its teams.">
            {(a) => (
              <select {...a} className="select" value={userId} onChange={(e) => setUserId(e.target.value)}>
                <option value="">Choose someone…</option>
                {candidates.map((m) => <option key={m.user_id} value={m.user_id}>{m.name} ({m.email})</option>)}
              </select>
            )}
          </Field>
          <Field label="Role on this team">
            {(a) => (
              <select {...a} className="select" value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="member">Member</option>
                <option value="lead">Team lead</option>
              </select>
            )}
          </Field>
          <ErrorNotice error={add.error} />
        </>
      )}
    </Modal>
  )
}

function EditTeamModal({ orgId, team, onClose }) {
  const toast = useToast()
  const [form, setForm] = useState({ name: team.name, description: team.description || '' })
  const save = useAction(() => api.patch(`/orgs/${orgId}/teams/${team.id}`, { name: form.name.trim(), description: form.description.trim() }), [keys.team(orgId, team.id), keys.teams(orgId)], {
    onSuccess: () => { toast.success('Team updated.'); onClose() },
  })
  return (
    <Modal
      title="Edit team"
      onClose={onClose}
      footer={
        <>
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={form.name.trim().length < 2 || save.isPending} onClick={() => save.mutate()}>Save changes</button>
        </>
      }
    >
      <Field label="Team name">{(a) => <input {...a} className="input" maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />}</Field>
      <Field label="Description">{(a) => <textarea {...a} className="textarea" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />}</Field>
      <ErrorNotice error={save.error} />
    </Modal>
  )
}
