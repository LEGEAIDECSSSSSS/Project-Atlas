import { useState } from 'react'
import { Link, useNavigate, useOutletContext } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { useTeams } from '../queries'
import { isOrgAdmin } from '../lib/rules'
import TeamModal from '../components/TeamModal'
import { Empty, Loading, PageHead } from '../ui/bits'

export default function Teams() {
  const { orgId, role } = useOutletContext()
  const admin = isOrgAdmin(role)
  const { data: teams = [], isLoading } = useTeams(orgId)
  const [creating, setCreating] = useState(false)
  const navigate = useNavigate()

  return (
    <>
      <PageHead
        title="Teams"
        sub={admin ? 'Every team in this organisation. Each has its own lead, members, tasks and board.' : 'The teams you’re part of in this organisation.'}
        actions={admin && <button className="btn btn-primary" onClick={() => setCreating(true)}><Plus size={18} /> New team</button>}
      />
      {isLoading ? (
        <Loading />
      ) : teams.length ? (
        <div className="rows">
          <div className="row row-team row-head">
            <span>Team</span><span className="hide-sm">Lead</span><span className="hide-sm">Members</span><span className="hide-sm">Open work</span><span className="cell-right">You</span>
          </div>
          {teams.map((t) => (
            <Link key={t.id} to={`/o/${orgId}/teams/${t.id}`} className="row row-team link-row">
              <div style={{ minWidth: 0 }}>
                <div className="title">{t.name}</div>
                {t.description && <div className="meta" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.description}</div>}
              </div>
              <span className="hide-sm">{t.leads.length ? t.leads.map((l) => l.name).join(', ') : <span className="chip pending">No lead</span>}</span>
              <span className="hide-sm">{t.member_count}</span>
              <span className="hide-sm">{t.open_todo_count}{t.overdue_todo_count > 0 && <span className="chip late" style={{ marginLeft: 8 }}>{t.overdue_todo_count} late</span>}</span>
              <span className="cell-right">{t.my_role === 'lead' ? <span className="chip lead">Team lead</span> : t.my_role ? <span className="chip">Member</span> : <span className="muted">—</span>}</span>
            </Link>
          ))}
        </div>
      ) : (
        <Empty title={admin ? 'Create your first team' : 'You’re not on a team yet'} action={admin && <button className="btn btn-primary" onClick={() => setCreating(true)}>New team</button>}>
          {admin ? 'A team gets its own board. Pick a lead who will manage its tasks and review finished work.' : 'Ask an admin or a team lead to add you.'}
        </Empty>
      )}
      {creating && <TeamModal orgId={orgId} onClose={() => setCreating(false)} onCreated={(team) => navigate(`/o/${orgId}/teams/${team.id}`)} />}
    </>
  )
}
