import { useEffect, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { CircleCheck, CircleX } from 'lucide-react'
import { api } from '../api'
import { normaliseEmail, validateEmail } from '../lib/email'
import AuthLayout from './AuthLayout'
import Field from '../ui/Field'
import { Loading } from '../ui/bits'
import { useToast } from '../ui/Toast'

export default function VerifyEmail() {
  const [params] = useSearchParams()
  const token = params.get('token')
  const [state, setState] = useState(token ? 'working' : 'failed')
  const [message, setMessage] = useState('')
  const ran = useRef(false)
  const toast = useToast()
  const [email, setEmail] = useState('')
  const [emailError, setEmailError] = useState('')

  useEffect(() => {
    if (!token || ran.current) return
    ran.current = true // one-time links: never submit twice (React StrictMode runs effects twice in dev)
    api
      .post('/auth/verify-email', { token })
      .then(() => setState('ok'))
      .catch((e) => {
        setMessage(e.message)
        setState('failed')
      })
  }, [token])

  async function resend(event) {
    event.preventDefault()
    const problem = validateEmail(email)
    setEmailError(problem)
    if (problem) return
    try {
      await api.post('/auth/resend-verification', { email: normaliseEmail(email) })
      toast.success('If that account needs confirming, a new link is on its way.')
    } catch (e) {
      toast.error(e.message)
    }
  }

  return (
    <AuthLayout>
      {state === 'working' && <Loading />}
      {state === 'ok' && (
        <>
          <div className="big-icon ok">
            <CircleCheck size={26} />
          </div>
          <h2>Email confirmed</h2>
          <p className="lede">Your account is ready. Log in to create an organisation or accept an invitation.</p>
          <Link to="/login" className="btn btn-primary btn-block">
            Log in
          </Link>
        </>
      )}
      {state === 'failed' && (
        <>
          <div className="big-icon bad">
            <CircleX size={26} />
          </div>
          <h2>That link didn’t work</h2>
          <p className="lede">{message || 'The link is missing or incomplete.'} Enter your email and we’ll send a fresh one.</p>
          <form onSubmit={resend} noValidate>
            <Field label="Email address" error={emailError}>
              {(a) => <input {...a} className="input" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />}
            </Field>
            <button className="btn btn-primary btn-block">Send a new link</button>
          </form>
          <p className="foot">
            <Link to="/login" className="link">Back to log in</Link>
          </p>
        </>
      )}
    </AuthLayout>
  )
}
