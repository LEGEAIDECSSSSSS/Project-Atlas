import { Link, Navigate } from 'react-router-dom'
import { Building2 } from 'lucide-react'
import { useAuth } from '../auth'
import { useMyInvitations, useMyOrgs } from '../queries'
import InvitationList from '../components/InvitationList'
import { Loading, PageHead } from '../ui/bits'

export default function Welcome() {
  const { user } = useAuth()
  const { data: orgs, isLoading } = useMyOrgs()
  const { data: invitations = [] } = useMyInvitations()
  if (isLoading) return <Loading />
  if (orgs?.length) return <Navigate to="/" replace />

  return (
    <>
      <PageHead
        title={`Welcome, ${user.name.split(' ')[0]}`}
        sub="You’re signed in but not part of an organisation yet. Start your own, or accept an invitation from someone who already has one."
      />
      {invitations.length > 0 && (
        <section className="section" style={{ marginTop: 0, marginBottom: 40 }}>
          <div className="section-head">
            <h2>Waiting for you</h2>
          </div>
          <InvitationList invitations={invitations} />
        </section>
      )}
      <section className="empty">
        <h3>Start an organisation</h3>
        <p>
          You’ll be its owner. Invite your colleagues by email, create teams, and choose a lead for each. You can belong to other organisations at the same time.
        </p>
        <Link to="/orgs/new" className="btn btn-primary">
          <Building2 size={18} /> Create organisation
        </Link>
      </section>
      <p className="muted" style={{ marginTop: 18, maxWidth: '60ch' }}>
        Joining someone else’s organisation works by invitation: ask an owner or admin to invite {user.email}. It will show up here and in your Invitations.
      </p>
    </>
  )
}
