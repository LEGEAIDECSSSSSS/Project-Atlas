import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from './api'

// Query keys live in one place so mutations can invalidate precisely.
export const keys = {
  orgs: ['orgs'],
  invitations: ['my-invitations'],
  myTodos: ['my-todos'],
  org: (orgId) => ['org', orgId],
  members: (orgId) => ['members', orgId],
  orgInvites: (orgId) => ['org-invites', orgId],
  activity: (orgId) => ['activity', orgId],
  teams: (orgId) => ['teams', orgId],
  team: (orgId, teamId) => ['team', orgId, teamId],
  tasks: (orgId, teamId) => ['tasks', orgId, teamId],
  todos: (orgId, teamId) => ['todos', orgId, teamId],
}

export const useMyOrgs = () => useQuery({ queryKey: keys.orgs, queryFn: () => api.get('/me/organisations') })
export const useMyInvitations = () => useQuery({ queryKey: keys.invitations, queryFn: () => api.get('/me/invitations') })
export const useMyTodos = () => useQuery({ queryKey: keys.myTodos, queryFn: () => api.get('/me/todos') })

export const useOrg = (orgId) =>
  useQuery({ queryKey: keys.org(orgId), queryFn: () => api.get(`/orgs/${orgId}`), retry: false, enabled: !!orgId })
export const useMembers = (orgId) => useQuery({ queryKey: keys.members(orgId), queryFn: () => api.get(`/orgs/${orgId}/members`) })
export const useOrgInvites = (orgId, enabled) =>
  useQuery({ queryKey: keys.orgInvites(orgId), queryFn: () => api.get(`/orgs/${orgId}/invitations`), enabled })
export const useActivity = (orgId, enabled) =>
  useQuery({ queryKey: keys.activity(orgId), queryFn: () => api.get(`/orgs/${orgId}/activity`), enabled })
export const useTeams = (orgId) => useQuery({ queryKey: keys.teams(orgId), queryFn: () => api.get(`/orgs/${orgId}/teams`) })
export const useTeam = (orgId, teamId) =>
  useQuery({ queryKey: keys.team(orgId, teamId), queryFn: () => api.get(`/orgs/${orgId}/teams/${teamId}`), retry: false })
export const useTasks = (orgId, teamId) =>
  useQuery({ queryKey: keys.tasks(orgId, teamId), queryFn: () => api.get(`/orgs/${orgId}/teams/${teamId}/tasks`) })
export const useTodos = (orgId, teamId) =>
  useQuery({ queryKey: keys.todos(orgId, teamId), queryFn: () => api.get(`/orgs/${orgId}/teams/${teamId}/todos`) })

/** Mutation helper: runs fn, then invalidates the given query keys. */
export function useAction(fn, invalidate = [], options = {}) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: fn,
    ...options,
    onSuccess: async (data, variables, context) => {
      await Promise.all(invalidate.map((key) => queryClient.invalidateQueries({ queryKey: key })))
      options.onSuccess?.(data, variables, context)
    },
  })
}
