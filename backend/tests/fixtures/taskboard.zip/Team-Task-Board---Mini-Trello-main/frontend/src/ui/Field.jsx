import { useId, useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'

/** Label + control + hint/error. `children` receives the generated id and aria props. */
export default function Field({ label, error, hint, children }) {
  const id = useId()
  const describedBy = error ? `${id}-e` : hint ? `${id}-h` : undefined
  return (
    <div className="field" data-invalid={!!error}>
      <label htmlFor={id}>{label}</label>
      {children({ id, 'aria-describedby': describedBy, 'aria-invalid': !!error })}
      {error ? (
        <span className="error" id={`${id}-e`} role="alert">
          {error}
        </span>
      ) : hint ? (
        <span className="hint" id={`${id}-h`}>
          {hint}
        </span>
      ) : null}
    </div>
  )
}

export function PasswordInput(props) {
  const [shown, setShown] = useState(false)
  return (
    <div className="pw-wrap">
      <input className="input" {...props} type={shown ? 'text' : 'password'} />
      <button type="button" onClick={() => setShown((s) => !s)} aria-label={shown ? 'Hide password' : 'Show password'}>
        {shown ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  )
}
