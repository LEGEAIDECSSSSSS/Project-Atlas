import { CircleAlert } from 'lucide-react'
import { initials, orgTileStyle } from '../lib/format'

export function Avatar({ name, size = 32 }) {
  return (
    <span className="avatar" style={{ ...orgTileStyle(name), '--size': `${size}px` }} aria-hidden="true">
      {initials(name)}
    </span>
  )
}

export function Loading() {
  return (
    <div className="loading" role="status" aria-label="Loading">
      <div className="spinner" />
    </div>
  )
}

export function Empty({ title, children, action }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  )
}

export function ErrorNotice({ error }) {
  if (!error) return null
  return (
    <div className="notice error" role="alert">
      <CircleAlert size={16} />
      <span>{error.message || String(error)}</span>
    </div>
  )
}

export function BrandMark({ size = 30 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="#e4efea" />
      <rect x="7" y="8" width="5" height="16" rx="1.5" fill="#12332d" />
      <rect x="14" y="8" width="5" height="10" rx="1.5" fill="#12332d" />
      <rect x="21" y="8" width="5" height="13" rx="1.5" fill="#e3a72f" />
    </svg>
  )
}

export function RoleChip({ role }) {
  const label = { owner: 'Owner', admin: 'Admin', member: 'Member', lead: 'Team lead' }[role] || role
  return <span className={`chip ${role}`}>{label}</span>
}

export function PageHead({ title, sub, actions }) {
  return (
    <div className="page-head">
      <div>
        <h1>{title}</h1>
        {sub && <p className="sub">{sub}</p>}
      </div>
      {actions && <div className="actions">{actions}</div>}
    </div>
  )
}
