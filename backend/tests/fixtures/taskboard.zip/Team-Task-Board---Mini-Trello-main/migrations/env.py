from logging.config import fileConfig

from alembic import context
from sqlmodel import SQLModel

import app.schemas.models  # noqa: F401  (registers every table)
from app.config.settings import make_engine, settings

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = SQLModel.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=settings.TEAM_TASK_BOARD_SCHEMA,
        target_metadata=target_metadata,
        literal_binds=True,
        render_as_batch=settings.TEAM_TASK_BOARD_SCHEMA.startswith("sqlite"),
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = make_engine(settings.TEAM_TASK_BOARD_SCHEMA)
    with engine.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=connection.dialect.name == "sqlite",
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
